Pridec branch changes export
============================

This archive contains all 126 files changed by the branch commit, plus a git-format-patch
for applying the commit to a clone.

Branch: arena/f1731340-pridec
Base:   8b217790e73cd183057e1c15bb5aef724699e7da
Commit: e227a1c89aaeef2897bd22ae9710639a44484383

Recommended apply/push flow from a clone of Consumed-by-Pride/Pridec:

  git switch -c arena/f1731340-pridec 8b217790e73cd183057e1c15bb5aef724699e7da
  git am branch-changes.patch
  git push origin arena/f1731340-pridec

If you already have that branch locally, switch to it before `git am` instead of creating it.
The patch includes `.github/workflows/compiler.yml`; pushing that file requires GitHub's
`workflows` permission. The previous Arena push was rejected for lacking that permission.

The `Pridec/` directory holds the changed file snapshots for inspection or manual copy. Apply
`branch-changes.patch` to preserve the commit metadata and exact diff; do not overlay both unless
you intend to resolve the same changes twice.
